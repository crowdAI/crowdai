import os
import sys
import numpy as np
import pandas as pd

# Take the folder argument
input_folder = sys.argv[1]
images_fn = os.listdir(input_folder)
images_df = pd.DataFrame({
        'filename': images_fn
    })
results_columns = ['product_id', 'nutrient_id', 'per_hundred', 'per_portion', 'percent']
nutrient_types_nb = 16

# Create the image dataframe
def get_image_id(filename):
    return int(filename.split('image-')[1].split('.jpg')[0])

images_df['id'] = images_df.applymap(get_image_id)
N = len(images_df)


# Create the result dataframe
def minus_ones(n):
    return np.zeros(n, dtype=np.float) - 1

results_df = pd.DataFrame({
        results_columns[0]: images_df['id'].repeat(nutrient_types_nb),
        results_columns[1]: range(1, nutrient_types_nb + 1) * N,
        results_columns[2]: minus_ones(N).repeat(nutrient_types_nb),
        results_columns[3]: minus_ones(N).repeat(nutrient_types_nb),
        results_columns[4]: minus_ones(N).repeat(nutrient_types_nb)
    })

# Write the result dataframe
def write_to_csv(results_df):
    results_df.to_csv(
        path_or_buf='product_nutrients.csv',
        index=False,
        header=False,
        columns=results_columns)
    return 'OK'

write_to_csv(results_df)

