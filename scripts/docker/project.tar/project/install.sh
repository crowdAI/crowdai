#!/bin/bash

# e.g.
# apt-get update -y
# apt-get install curl -y