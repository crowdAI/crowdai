#!/bin/bash

if [ $# -eq 1 ]; then
	# Run my python code
	python no-strategy.py "$1"
else
	echo "1 argument expected: path of (images) input folder"
fi
